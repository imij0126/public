package com.kh.practice.numRange.exception;

public class NumRangeException extends Exception {
    public NumRangeException(){}
    public NumRangeException(String msg){
        super (msg);
    }
}
